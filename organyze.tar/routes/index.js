const express = require('express');
const router = express.Router();
const path = require('path');

// Rota raiz redireciona para login
router.get('/', (req, res) => {
  res.redirect('/login');
});

// Rota de login
router.get('/login', (req, res) => {
  res.render(path.join(__dirname, '../views/pages/login'));
});

// Rota home
router.get('/home', (req, res) => {
  res.render(path.join(__dirname, '../views/layout/main'), {
    pageTitle: 'Home',
    contentPage: path.join(__dirname, '../views/pages/home')
  });
});

router.get('/tasks/new', (req, res) => {
  res.render(path.join(__dirname, '../views/layout/main'), {
    pageTitle: 'Adicionar Tarefa',
    contentPage: path.join(__dirname, '../views/pages/new-task')
  });
});

router.get('/tasks/:id/edit', (req, res) => {
  res.render(path.join(__dirname, '../views/layout/main'), {
    pageTitle: 'Editar Tarefa',
    contentPage: path.join(__dirname, '../views/pages/edit-task')
  });
});

module.exports = router;

